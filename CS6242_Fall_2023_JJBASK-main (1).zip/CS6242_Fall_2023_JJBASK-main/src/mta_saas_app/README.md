# Setup instructions

https://dotnet.microsoft.com/en-us/download/dotnet/7.0

https://nodejs.org/en

https://visualstudio.microsoft.com/vs/community/

https://vuejs.org/


# Build instructions

To run this cloud application locally, use microsoft visual studio (Microsoft Visual Studio Community 2022 (64-bit) - Current
Version 17.6.4) to open the .sln file

Clean

Build

Run

# Output

2 browsers should open up. One for UI and another one for backend.

