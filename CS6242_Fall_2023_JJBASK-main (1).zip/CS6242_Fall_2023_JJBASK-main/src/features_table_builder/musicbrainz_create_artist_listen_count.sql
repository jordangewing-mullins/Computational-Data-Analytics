CREATE TABLE musicbrainz.artist_listen_count (
  artist_msid UUID NOT NULL,  
  listen_count INTEGER NOT NULL  
);