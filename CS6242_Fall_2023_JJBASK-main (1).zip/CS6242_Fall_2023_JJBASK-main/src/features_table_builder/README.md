## feature table builder

There are 2 main tables which are used for building the ML model

### mta table
musicbrainz_create_mta.sql

### pta_mta table
musicbrainz_create_pta_mta.sql
