CREATE TABLE musicbrainz.artist_user_count (
  artist_msid UUID NOT NULL,  
  user_count INTEGER NOT NULL  
);