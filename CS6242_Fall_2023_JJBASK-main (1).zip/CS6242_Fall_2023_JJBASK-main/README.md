# CS6242_Fall_2023_JJBASK
## Music Industry Visualization And Tour Analytics 
### [Live mivta cloud application ](http://mivtaui.a9acdfebamb6gyfr.westus2.azurecontainer.io/)
## Musicbrainz PostgreSQL server on Azure portal:
user="musicbrainz"

password="Git62036242"

host="musicbrainz.postgres.database.azure.com"

port=5432

database="musicbrainz"

**Note**:
This server is controlled by a firewall so even with the user name and password, server is not accessible.
It's accessible only when an IPv4 WAN address of the person wishing to access this data base is provided to spothana3@gatech.edu.
Access is restricted as it costs money to host several hundreds of gigabytes of data.

## Software tools and frameworks used in this project

https://www.postgresql.org/

https://dotnet.microsoft.com/en-us/download/dotnet/7.0

https://nodejs.org/en

https://visualstudio.microsoft.com/vs/community/

https://vuejs.org/

https://www.python.org/

https://portal.azure.com/

https://azure.microsoft.com/en-us/products/data-studio

https://github.com/creativetimofficial/vue-black-dashboard

https://www.docker.com/products/docker-desktop/

https://scikit-learn.org/stable/

![Alt text](documents/Music_tour_success_prediction_poster.jpg)

