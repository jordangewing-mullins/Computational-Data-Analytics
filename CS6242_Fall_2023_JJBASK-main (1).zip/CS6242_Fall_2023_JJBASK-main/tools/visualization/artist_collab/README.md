## Music artists' collaboration graph

Run 'python -m http.server  9001' in artist_collab directory

On a browser, go to http://localhost:9001/artist_collab.html to get the live visualization
