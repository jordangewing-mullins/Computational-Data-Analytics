# MIVTA Visualization
## music artist vs release count
![Alt text](ArtistVsReleaseCount.png)

## country vs music artist count
![Alt text](countryvsartistcount.png)

## country vs music release count
![Alt text](countryvsreleasecount.png)

## music artist vs listen count
![Alt text](listen_count_by_artist_name.png)

## music artist vs listen count
![Alt text](listen_count_by_artist_name.png)

## music artist vs user count
![Alt text](unique_users_count_by_artist_name.png)

## music artist collab graph
![Alt text](top25_artist_collab.png)
