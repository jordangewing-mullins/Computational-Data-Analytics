select  name,lc
from musicbrainz.mta
ORDER BY lc DESC
LIMIT 20