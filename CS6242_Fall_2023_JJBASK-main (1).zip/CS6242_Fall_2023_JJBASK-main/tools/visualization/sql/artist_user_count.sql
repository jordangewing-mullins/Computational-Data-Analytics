select name, uc
from musicbrainz.mta
ORDER BY uc DESC
LIMIT 20;