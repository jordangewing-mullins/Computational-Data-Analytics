select  id
,gid
,name
,type
,area
,gender
,gross_revenue
,tickets_sold
from musicbrainz.pollstar_top150_artist